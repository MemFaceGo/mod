![Logo](sprites/ReadMe/Better-Blocks_Mod.png)

# Better-Blocks-Mod

<details> 
  <summary>ENG Description</summary>
Better-Blocks-Mod: this mod adds more blocks , materials and enemies.

The mod is being developed specifically for mindustry.ru.

For all questions, write to Discord: https://discord.mindustry.ru/
![Discord Shield](https://discordapp.com/api/guilds/658670734222163989/widget.png?style=shield)
</details>

<details> 
  <summary>RUS Description</summary>
Better-Blocks-Mod: Этот мод добавляет больше блоков, материалов и врагов.


Мод разрабатывается специально для mindustry.ru.

По всем вопросам пишите в Discord: https://discord.mindustry.ru/
![Discord Shield](https://discordapp.com/api/guilds/658670734222163989/widget.png?style=shield)
</details>


# Developers
- [MemFaceGo](https://github.com/MemFaceGo) (Russian - Owner)
- [MINDUSTRYRU](https://github.com/MINDUSTRYRU) (First Developer)

# Discord Server

<a href="https://discord.mindustry.ru/"><img src="https://discordapp.com/api/guilds/658670734222163989/widget.png?style=banner4" alt="Discord Banner 4"/></a>